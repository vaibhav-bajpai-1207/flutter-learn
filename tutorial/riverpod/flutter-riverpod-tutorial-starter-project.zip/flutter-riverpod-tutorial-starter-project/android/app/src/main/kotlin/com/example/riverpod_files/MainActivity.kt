package com.example.riverpod_files

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
